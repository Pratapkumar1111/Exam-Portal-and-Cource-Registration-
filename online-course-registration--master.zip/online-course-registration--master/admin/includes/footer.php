<footer>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                &copy; 2023 Online Course Registration
            </div>

        </div>
    </div>
</footer>